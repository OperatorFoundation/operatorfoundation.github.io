import circuitpython_base64
import os
import time

import busio
import sdcardio
import storage

sdDirectoryName = '/sd'

# https://learn.adafruit.com/adafruit-microsd-spi-sdio/using-sdcardio


class StorageController:

    def __init__(self, settings):
        self.settings = settings
        if self.settings.SD_CARD_DET.value is True:
            print("SD Card missing?")
            print("waiting for SD Card")
        while self.settings.SD_CARD_DET.value is True:
            time.sleep(1)
        # print("SD Card detected")
        time.sleep(1)  # detection switch closes before card fully inserted, wait for insertion

        # SPI bus on specific pins:
        # Using specific pins to better support multiple MicroMod processors
        spi = busio.SPI(self.settings.SCK, MOSI=self.settings.COPI, MISO=self.settings.CIPO)

        # sd card object
        sdCard = sdcardio.SDCard(spi, self.settings.SD_CS)

        # filesystem object
        vfs = storage.VfsFat(sdCard)

        # mount the sdcard's filesystem into the CircuitPython filesystem
        # making the path /sd allows you to read and write from the card
        storage.mount(vfs, sdDirectoryName)
        # self.printStoredFiles()
        # print("Storage Initialized")


    def test_storage_controller(self):
        filename = "/test2.txt"
        testWriteFile = open(sdDirectoryName + filename, "w")
        testWriteFile.write("This is a test line! \n")
        testWriteFile.write("This is another test line! \n")
        testWriteFile.close()

        testReadFile = open(sdDirectoryName + filename, "r")
        testReadFileOutput = testReadFile.read()
        testReadFile.close()
        print("Reading contents of the test file: ")
        print(testReadFileOutput)


    def printStoredFiles(self):
        storedFiles = os.listdir(sdDirectoryName)
        print("\nStored Files: ")

        for file in storedFiles:
            print(file)

        print("\n")

    def readPublicKey(self) -> bytes:
        return self.read("PUB")
        # b64Key = self.read("PUB")
        # print("readPublicKey found a key: ", b64Key)
        # print("readPublicKey key size: ", len(b64Key))
        # return circuitpython_base64.b64decode(b64Key)

    def writePublicKey(self, data):
        self.write("PUB", data)

    def readPrivateKey(self) -> bytes:
        return self.read("PRIV")

    def writePrivateKey(self, data):
        self.write("PRIV", data)

    def readSharedSecret(self) -> bytes:
        return self.read("SHARE")

    def writeSharedSecret(self, data):
        self.write("SHARE", data)

    def read(self, filename):
        with open(sdDirectoryName + "/" + filename, 'rb') as f:
            return f.read()

    def write(self, filename, data):
        with open(sdDirectoryName + "/" + filename, 'wb') as f:
            f.write(data)

    def saveFile(self):
        with open("/sd/test.txt", "w") as f:
            f.write("Test writing to and saving file.\r\n")

    def readFile(self):
        with open("/sd/test.txt", "r") as f:
            print("Test reading line from file: ")
            print(f.readline())

"""
Primary classes for performing signing and verification operations.
"""

from os import urandom
from adafruit_hashlib import sha1
from .eddsa import PublicKey, PrivateKey
from .ecdsa import Public_key, InvalidPointError, Signature, Private_key
from .curves import NIST192p
from .util import string_to_number, sigdecode_string, bit_length, number_to_string, randrange
from ._compat import normalise_bytes
from .errors import MalformedPointError
from .ellipticcurve import PointJacobi, CurveEdTw, PointEdwards


__all__ = [
    "BadSignatureError",
    "BadDigestError",
    "SigningKey",
    "VerifyingKey",
    "MalformedPointError",
]


class BadSignatureError(Exception):
    """
    Raised when verification of signature failed.

    Will be raised irrespective of reason of the failure:

    * the calculated or provided hash does not match the signature
    * the signature does not match the curve/public key
    * the encoding of the signature is malformed
    * the size of the signature does not match the curve of the VerifyingKey
    """

    pass


class BadDigestError(Exception):
    """Raised in case the selected hash is too large for the curve."""

    pass


def _truncate_and_convert_digest(digest, curve, allow_truncate):
    """Truncates and converts digest to an integer."""
    if not allow_truncate:
        if len(digest) > curve.baselen:
            raise BadDigestError(
                "this curve ({0}) is too short "
                "for the length of your digest ({1})".format(
                    curve.name, 8 * len(digest)
                )
            )
    else:
        digest = digest[: curve.baselen]
    number = string_to_number(digest)
    if allow_truncate:
        max_length = bit_length(curve.order)
        # we don't use bit_length(number) as that truncates leading zeros
        length = len(digest) * 8

        # See NIST FIPS 186-4:
        #
        # When the length of the output of the hash function is greater
        # than N (i.e., the bit length of q), then the leftmost N bits of
        # the hash function output block shall be used in any calculation
        # using the hash function output during the generation or
        # verification of a digital signature.
        #
        # as such, we need to shift-out the low-order bits:
        number >>= max(0, length - max_length)

    return number


class VerifyingKey(object):
    """
    Class for handling keys that can verify signatures (public keys).

    :ivar `~ecdsa.curves.Curve` ~.curve: The Curve over which all the
        cryptographic operations will take place
    :ivar default_hashfunc: the function that will be used for hashing the
        data. Should implement the same API as hashlib.sha1
    :vartype default_hashfunc: callable
    :ivar pubkey: the actual public key
    :vartype pubkey: ~ecdsa.ecdsa.Public_key
    """

    def __init__(self, _error__please_use_generate=None):
        """Unsupported, please use one of the classmethods to initialise."""
        if not _error__please_use_generate:
            raise TypeError(
                "Please use VerifyingKey.generate() to construct me"
            )
        self.curve = None
        self.default_hashfunc = None
        self.pubkey = None

    def __repr__(self):
        pub_key = self.to_string("compressed")
        if self.default_hashfunc:
            hash_name = self.default_hashfunc().name
        else:
            hash_name = "None"
        return "VerifyingKey.from_string({0!r}, {1!r}, {2})".format(
            pub_key, self.curve, hash_name
        )

    def __eq__(self, other):
        """Return True if the points are identical, False otherwise."""
        if isinstance(other, VerifyingKey):
            return self.curve == other.curve and self.pubkey == other.pubkey
        return NotImplemented

    def __ne__(self, other):
        """Return False if the points are identical, True otherwise."""
        return not self == other

    @classmethod
    def from_public_point(
        cls, point, curve=NIST192p, hashfunc=sha1, validate_point=True
    ):
        """
        Initialise the object from a Point object.

        This is a low-level method, generally you will not want to use it.

        :param point: The point to wrap around, the actual public key
        :type point: ~ecdsa.ellipticcurve.AbstractPoint
        :param curve: The curve on which the point needs to reside, defaults
            to NIST192p
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            verification, needs to implement the same interface
            as :py:class:`hashlib.sha1`
        :type hashfunc: callable
        :type bool validate_point: whether to check if the point lays on curve
            should always be used if the public point is not a result
            of our own calculation

        :raises MalformedPointError: if the public point does not lay on the
            curve

        :return: Initialised VerifyingKey object
        :rtype: VerifyingKey
        """
        self = cls(_error__please_use_generate=True)
        if isinstance(curve.curve, CurveEdTw):
            raise ValueError("Method incompatible with Edwards curves")
        if not isinstance(point, PointJacobi):
            point = PointJacobi.from_affine(point)
        self.curve = curve
        self.default_hashfunc = hashfunc
        try:
            self.pubkey = Public_key(
                curve.generator, point, validate_point
            )
        except InvalidPointError:
            raise MalformedPointError("Point does not lay on the curve")
        self.pubkey.order = curve.order
        return self

    def precompute(self, lazy=False):
        """
        Precompute multiplication tables for faster signature verification.

        Calling this method will cause the library to precompute the
        scalar multiplication tables, used in signature verification.
        While it's an expensive operation (comparable to performing
        as many signatures as the bit size of the curve, i.e. 256 for NIST256p)
        it speeds up verification 2 times. You should call this method
        if you expect to verify hundreds of signatures (or more) using the same
        VerifyingKey object.

        Note: You should call this method only once, this method generates a
        new precomputation table every time it's called.

        :param bool lazy: whether to calculate the precomputation table now
           (if set to False) or if it should be delayed to the time of first
           use (when set to True)
        """
        if isinstance(self.curve.curve, CurveEdTw):
            pt = self.pubkey.point
            self.pubkey.point = PointEdwards(
                pt.curve(),
                pt.x(),
                pt.y(),
                1,
                pt.x() * pt.y(),
                self.curve.order,
                generator=True,
            )
        else:
            self.pubkey.point = PointJacobi.from_affine(
                self.pubkey.point, True
            )
        # as precomputation in now delayed to the time of first use of the
        # point and we were asked specifically to precompute now, make
        # sure the precomputation is performed now to preserve the behaviour
        if not lazy:
            self.pubkey.point * 2

    @classmethod
    def from_string(
        cls,
        string,
        curve=NIST192p,
        hashfunc=sha1,
        validate_point=True,
        valid_encodings=None,
    ):
        """
        Initialise the object from byte encoding of public key.

        The method does accept and automatically detect the type of point
        encoding used. It supports the :term:`raw encoding`,
        :term:`uncompressed`, :term:`compressed`, and :term:`hybrid` encodings.
        It also works with the native encoding of Ed25519 and Ed448 public
        keys (technically those are compressed, but encoded differently than
        in other signature systems).

        Note, while the method is named "from_string" it's a misnomer from
        Python 2 days when there were no binary strings. In Python 3 the
        input needs to be a bytes-like object.

        :param string: single point encoding of the public key
        :type string: :term:`bytes-like object`
        :param curve: the curve on which the public key is expected to lay
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            verification, needs to implement the same interface as
            hashlib.sha1. Ignored for EdDSA.
        :type hashfunc: callable
        :param validate_point: whether to verify that the point lays on the
            provided curve or not, defaults to True. Ignored for EdDSA.
        :type validate_point: bool
        :param valid_encodings: list of acceptable point encoding formats,
            supported ones are: :term:`uncompressed`, :term:`compressed`,
            :term:`hybrid`, and :term:`raw encoding` (specified with ``raw``
            name). All formats by default (specified with ``None``).
            Ignored for EdDSA.
        :type valid_encodings: :term:`set-like object`

        :raises MalformedPointError: if the public point does not lay on the
            curve or the encoding is invalid

        :return: Initialised VerifyingKey object
        :rtype: VerifyingKey
        """
        if isinstance(curve.curve, CurveEdTw):
            self = cls(_error__please_use_generate=True)
            self.curve = curve
            self.default_hashfunc = None  # ignored for EdDSA
            try:
                self.pubkey = PublicKey(curve.generator, string)
            except ValueError:
                raise MalformedPointError("Malformed point for the curve")
            return self

        point = PointJacobi.from_bytes(
            curve.curve,
            string,
            validate_encoding=validate_point,
            valid_encodings=valid_encodings,
        )
        return cls.from_public_point(point, curve, hashfunc, validate_point)

    @classmethod
    def from_public_key_recovery(
        cls,
        signature,
        data,
        curve,
        hashfunc=sha1,
        sigdecode=sigdecode_string,
        allow_truncate=True,
    ):
        """
        Return keys that can be used as verifiers of the provided signature.

        Tries to recover the public key that can be used to verify the
        signature, usually returns two keys like that.

        :param signature: the byte string with the encoded signature
        :type signature: bytes-like object
        :param data: the data to be hashed for signature verification
        :type data: bytes-like object
        :param curve: the curve over which the signature was performed
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            verification, needs to implement the same interface as hashlib.sha1
        :type hashfunc: callable
        :param sigdecode: Callable to define the way the signature needs to
            be decoded to an object, needs to handle `signature` as the
            first parameter, the curve order (an int) as the second and return
            a tuple with two integers, "r" as the first one and "s" as the
            second one. See :func:`ecdsa.util.sigdecode_string` and
            :func:`ecdsa.util.sigdecode_der` for examples.
        :param bool allow_truncate: if True, the provided hashfunc can generate
            values larger than the bit size of the order of the curve, the
            extra bits (at the end of the digest) will be truncated.
        :type sigdecode: callable

        :return: Initialised VerifyingKey objects
        :rtype: list of VerifyingKey
        """
        if isinstance(curve.curve, CurveEdTw):
            raise ValueError("Method unsupported for Edwards curves")
        data = normalise_bytes(data)
        digest = hashfunc(data).digest()
        return cls.from_public_key_recovery_with_digest(
            signature,
            digest,
            curve,
            hashfunc=hashfunc,
            sigdecode=sigdecode,
            allow_truncate=allow_truncate,
        )

    @classmethod
    def from_public_key_recovery_with_digest(
        cls,
        signature,
        digest,
        curve,
        hashfunc=sha1,
        sigdecode=sigdecode_string,
        allow_truncate=False,
    ):
        """
        Return keys that can be used as verifiers of the provided signature.

        Tries to recover the public key that can be used to verify the
        signature, usually returns two keys like that.

        :param signature: the byte string with the encoded signature
        :type signature: bytes-like object
        :param digest: the hash value of the message signed by the signature
        :type digest: bytes-like object
        :param curve: the curve over which the signature was performed
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            verification, needs to implement the same interface as hashlib.sha1
        :type hashfunc: callable
        :param sigdecode: Callable to define the way the signature needs to
            be decoded to an object, needs to handle `signature` as the
            first parameter, the curve order (an int) as the second and return
            a tuple with two integers, "r" as the first one and "s" as the
            second one. See :func:`ecdsa.util.sigdecode_string` and
            :func:`ecdsa.util.sigdecode_der` for examples.
        :type sigdecode: callable
        :param bool allow_truncate: if True, the provided hashfunc can generate
            values larger than the bit size of the order of the curve (and
            the length of provided `digest`), the extra bits (at the end of the
            digest) will be truncated.

        :return: Initialised VerifyingKey object
        :rtype: VerifyingKey
        """
        if isinstance(curve.curve, CurveEdTw):
            raise ValueError("Method unsupported for Edwards curves")
        generator = curve.generator
        r, s = sigdecode(signature, generator.order())
        sig = Signature(r, s)

        digest = normalise_bytes(digest)
        digest_as_number = _truncate_and_convert_digest(
            digest, curve, allow_truncate
        )
        pks = sig.recover_public_keys(digest_as_number, generator)

        # Transforms the ecdsa.Public_key object into a VerifyingKey
        verifying_keys = [
            cls.from_public_point(pk.point, curve, hashfunc) for pk in pks
        ]
        return verifying_keys

    def to_string(self, encoding="raw"):
        """
        Convert the public key to a byte string.

        The method by default uses the :term:`raw encoding` (specified
        by `encoding="raw"`. It can also output keys in :term:`uncompressed`,
        :term:`compressed` and :term:`hybrid` formats.

        Remember that the curve identification is not part of the encoding
        so to decode the point using :func:`~VerifyingKey.from_string`, curve
        needs to be specified.

        Note: while the method is called "to_string", it's a misnomer from
        Python 2 days when character strings and byte strings shared type.
        On Python 3 the returned type will be `bytes`.

        :return: :term:`raw encoding` of the public key (public point) on the
            curve
        :rtype: bytes
        """
        assert encoding in ("raw", "uncompressed", "compressed", "hybrid")
        return self.pubkey.point.to_bytes(encoding)

class SigningKey(object):
    """
    Class for handling keys that can create signatures (private keys).

    :ivar `~ecdsa.curves.Curve` curve: The Curve over which all the
        cryptographic operations will take place
    :ivar default_hashfunc: the function that will be used for hashing the
        data. Should implement the same API as :py:class:`hashlib.sha1`
    :ivar int baselen: the length of a :term:`raw encoding` of private key
    :ivar `~ecdsa.keys.VerifyingKey` verifying_key: the public key
        associated with this private key
    :ivar `~ecdsa.ecdsa.Private_key` privkey: the actual private key
    """

    def __init__(self, _error__please_use_generate=None):
        """Unsupported, please use one of the classmethods to initialise."""
        if not _error__please_use_generate:
            raise TypeError("Please use SigningKey.generate() to construct me")
        self.curve = None
        self.default_hashfunc = None
        self.baselen = None
        self.verifying_key = None
        self.privkey = None

    def __eq__(self, other):
        """Return True if the points are identical, False otherwise."""
        if isinstance(other, SigningKey):
            return (
                self.curve == other.curve
                and self.verifying_key == other.verifying_key
                and self.privkey == other.privkey
            )
        return NotImplemented

    def __ne__(self, other):
        """Return False if the points are identical, True otherwise."""
        return not self == other

    @classmethod
    def _twisted_edwards_keygen(cls, curve, entropy):
        """Generate a private key on a Twisted Edwards curve."""
        if not entropy:
            entropy = urandom
        random = entropy(curve.baselen)
        private_key = PrivateKey(curve.generator, random)
        public_key = private_key.public_key()

        verifying_key = VerifyingKey.from_string(
            public_key.public_key(), curve
        )

        self = cls(_error__please_use_generate=True)
        self.curve = curve
        self.default_hashfunc = None
        self.baselen = curve.baselen
        self.privkey = private_key
        self.verifying_key = verifying_key
        return self

    @classmethod
    def _weierstrass_keygen(cls, curve, entropy, hashfunc):
        """Generate a private key on a Weierstrass curve."""
        secexp = randrange(curve.order, entropy)
        return cls.from_secret_exponent(secexp, curve, hashfunc)

    @classmethod
    def generate(cls, curve=NIST192p, entropy=None, hashfunc=sha1):
        """
        Generate a random private key.

        :param curve: The curve on which the point needs to reside, defaults
            to NIST192p
        :type curve: ~ecdsa.curves.Curve
        :param entropy: Source of randomness for generating the private keys,
            should provide cryptographically secure random numbers if the keys
            need to be secure. Uses os.urandom() by default.
        :type entropy: callable
        :param hashfunc: The default hash function that will be used for
            signing, needs to implement the same interface
            as hashlib.sha1
        :type hashfunc: callable

        :return: Initialised SigningKey object
        :rtype: SigningKey
        """
        if isinstance(curve.curve, CurveEdTw):
            return cls._twisted_edwards_keygen(curve, entropy)
        return cls._weierstrass_keygen(curve, entropy, hashfunc)

    @classmethod
    def from_secret_exponent(cls, secexp, curve=NIST192p, hashfunc=sha1):
        """
        Create a private key from a random integer.

        Note: it's a low level method, it's recommended to use the
        :func:`~SigningKey.generate` method to create private keys.

        :param int secexp: secret multiplier (the actual private key in ECDSA).
            Needs to be an integer between 1 and the curve order.
        :param curve: The curve on which the point needs to reside
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            signing, needs to implement the same interface
            as hashlib.sha1
        :type hashfunc: callable

        :raises MalformedPointError: when the provided secexp is too large
            or too small for the curve selected
        :raises RuntimeError: if the generation of public key from private
            key failed

        :return: Initialised SigningKey object
        :rtype: SigningKey
        """
        if isinstance(curve.curve, CurveEdTw):
            raise ValueError(
                "Edwards keys don't support setting the secret scalar "
                "(exponent) directly"
            )
        self = cls(_error__please_use_generate=True)
        self.curve = curve
        self.default_hashfunc = hashfunc
        self.baselen = curve.baselen
        n = curve.order
        if not 1 <= secexp < n:
            raise MalformedPointError(
                "Invalid value for secexp, expected integer "
                "between 1 and {0}".format(n)
            )
        pubkey_point = curve.generator * secexp
        if hasattr(pubkey_point, "scale"):
            pubkey_point = pubkey_point.scale()
        self.verifying_key = VerifyingKey.from_public_point(
            pubkey_point, curve, hashfunc, False
        )
        pubkey = self.verifying_key.pubkey
        self.privkey = Private_key(pubkey, secexp)
        self.privkey.order = n
        return self

    @classmethod
    def from_string(cls, string, curve=NIST192p, hashfunc=sha1):
        """
        Decode the private key from :term:`raw encoding`.

        Note: the name of this method is a misnomer coming from days of
        Python 2, when binary strings and character strings shared a type.
        In Python 3, the expected type is `bytes`.

        :param string: the raw encoding of the private key
        :type string: :term:`bytes-like object`
        :param curve: The curve on which the point needs to reside
        :type curve: ~ecdsa.curves.Curve
        :param hashfunc: The default hash function that will be used for
            signing, needs to implement the same interface
            as hashlib.sha1
        :type hashfunc: callable

        :raises MalformedPointError: if the length of encoding doesn't match
            the provided curve or the encoded values is too large
        :raises RuntimeError: if the generation of public key from private
            key failed

        :return: Initialised SigningKey object
        :rtype: SigningKey
        """
        string = normalise_bytes(string)

        if len(string) != curve.baselen:
            raise MalformedPointError(
                "Invalid length of private key, received {0}, "
                "expected {1}".format(len(string), curve.baselen)
            )
        if isinstance(curve.curve, CurveEdTw):
            self = cls(_error__please_use_generate=True)
            self.curve = curve
            self.default_hashfunc = None  # Ignored for EdDSA
            self.baselen = curve.baselen
            self.privkey = PrivateKey(curve.generator, string)
            self.verifying_key = VerifyingKey.from_string(
                self.privkey.public_key().public_key(), curve
            )
            return self
        secexp = string_to_number(string)
        return cls.from_secret_exponent(secexp, curve, hashfunc)

    def to_string(self):
        """
        Convert the private key to :term:`raw encoding`.

        Note: while the method is named "to_string", its name comes from
        Python 2 days, when binary and character strings used the same type.
        The type used in Python 3 is `bytes`.

        :return: raw encoding of private key
        :rtype: bytes
        """
        if isinstance(self.curve.curve, CurveEdTw):
            return bytes(self.privkey.private_key)
        secexp = self.privkey.secret_multiplier
        s = number_to_string(secexp, self.privkey.order)
        return s

    def get_verifying_key(self):
        """
        Return the VerifyingKey associated with this private key.

        Equivalent to reading the `verifying_key` field of an instance.

        :return: a public key that can be used to verify the signatures made
            with this SigningKey
        :rtype: VerifyingKey
        """
        return self.verifying_key
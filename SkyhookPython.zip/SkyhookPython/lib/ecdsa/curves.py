import gc
gc.collect()
from .ellipticcurve import CurveEdTw
from .eddsa import curve_ed25519, generator_ed25519, curve_ed448, generator_ed448
from .ecdsa import (curve_112r1, generator_112r1, curve_112r2, generator_112r2, curve_128r1, generator_128r1,
                    curve_160r1, generator_160r1, curve_192, generator_192, curve_224, generator_224, curve_256,
                    generator_256,
                    curve_384, generator_384, curve_521, generator_521, curve_secp256k1, generator_secp256k1,
                    curve_brainpoolp160r1,
                    generator_brainpoolp160r1, curve_brainpoolp160t1, generator_brainpoolp160t1, curve_brainpoolp192r1,
                    generator_brainpoolp192r1, curve_brainpoolp192t1, generator_brainpoolp192t1, curve_brainpoolp224r1,
                    generator_brainpoolp224r1, curve_brainpoolp512t1, generator_brainpoolp512t1, curve_brainpoolp384r1,
                    generator_brainpoolp384r1, curve_brainpoolp384t1, generator_brainpoolp384t1, curve_brainpoolp512r1,
                    generator_brainpoolp512r1, curve_brainpoolp320t1, generator_brainpoolp320t1, curve_brainpoolp320r1,
                    generator_brainpoolp320r1, curve_brainpoolp256t1, generator_brainpoolp256t1, curve_brainpoolp256r1,
                    generator_brainpoolp256r1, curve_brainpoolp224t1, generator_brainpoolp224t1)

from .util import orderlen
from ._compat import bit_length
gc.collect()


# orderlen was defined in this module previously, so keep it in __all__,
# will need to mark it as deprecated later
__all__ = [
    "UnknownCurveError",
    "orderlen",
    "Curve",
    "SECP112r1",
    "SECP112r2",
    "SECP128r1",
    "SECP160r1",
    "NIST192p",
    "NIST224p",
    "NIST256p",
    "NIST384p",
    "NIST521p",
    "curves",
    "find_curve",
    "curve_by_name",
    "SECP256k1",
    "BRAINPOOLP160r1",
    "BRAINPOOLP160t1",
    "BRAINPOOLP192r1",
    "BRAINPOOLP192t1",
    "BRAINPOOLP224r1",
    "BRAINPOOLP224t1",
    "BRAINPOOLP256r1",
    "BRAINPOOLP256t1",
    "BRAINPOOLP320r1",
    "BRAINPOOLP320t1",
    "BRAINPOOLP384r1",
    "BRAINPOOLP384t1",
    "BRAINPOOLP512r1",
    "BRAINPOOLP512t1",
    "PRIME_FIELD_OID",
    "CHARACTERISTIC_TWO_FIELD_OID",
    "Ed25519",
    "Ed448",
]

PRIME_FIELD_OID = (1, 2, 840, 10045, 1, 1)
CHARACTERISTIC_TWO_FIELD_OID = (1, 2, 840, 10045, 1, 2)


class UnknownCurveError(Exception):
    pass


class Curve:
    def __init__(self, name, curve, generator, oid, openssl_name=None):
        self.name = name
        self.openssl_name = openssl_name  # maybe None
        self.curve = curve
        self.generator = generator
        self.order = generator.order()
        if isinstance(curve, CurveEdTw):
            # EdDSA keys are special in that both private and public
            # are the same size (as it's defined only with compressed points)

            # +1 for the sign bit and then round up
            self.baselen = (bit_length(curve.p()) + 1 + 7) // 8
            self.verifying_key_length = self.baselen
        else:
            self.baselen = orderlen(self.order)
            self.verifying_key_length = 2 * orderlen(curve.p())
        self.signature_length = 2 * self.baselen
        self.oid = oid

    def __eq__(self, other):
        if isinstance(other, Curve):
            return (
                    self.curve == other.curve and self.generator == other.generator
            )
        return NotImplemented

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return self.name


# the SEC curves
SECP112r1 = Curve(
    "SECP112r1",
    curve_112r1,
    generator_112r1,
    (1, 3, 132, 0, 6),
    "secp112r1",
)

SECP112r2 = Curve(
    "SECP112r2",
    curve_112r2,
    generator_112r2,
    (1, 3, 132, 0, 7),
    "secp112r2",
)

SECP128r1 = Curve(
    "SECP128r1",
    curve_128r1,
    generator_128r1,
    (1, 3, 132, 0, 28),
    "secp128r1",
)

SECP160r1 = Curve(
    "SECP160r1",
    curve_160r1,
    generator_160r1,
    (1, 3, 132, 0, 8),
    "secp160r1",
)

# the NIST curves
NIST192p = Curve(
    "NIST192p",
    curve_192,
    generator_192,
    (1, 2, 840, 10045, 3, 1, 1),
    "prime192v1",
)

NIST224p = Curve(
    "NIST224p",
    curve_224,
    generator_224,
    (1, 3, 132, 0, 33),
    "secp224r1",
)

NIST256p = Curve(
    "NIST256p",
    curve_256,
    generator_256,
    (1, 2, 840, 10045, 3, 1, 7),
    "prime256v1",
)

NIST384p = Curve(
    "NIST384p",
    curve_384,
    generator_384,
    (1, 3, 132, 0, 34),
    "secp384r1",
)

NIST521p = Curve(
    "NIST521p",
    curve_521,
    generator_521,
    (1, 3, 132, 0, 35),
    "secp521r1",
)

SECP256k1 = Curve(
    "SECP256k1",
    curve_secp256k1,
    generator_secp256k1,
    (1, 3, 132, 0, 10),
    "secp256k1",
)

BRAINPOOLP160r1 = Curve(
    "BRAINPOOLP160r1",
    curve_brainpoolp160r1,
    generator_brainpoolp160r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 1),
    "brainpoolP160r1",
)

BRAINPOOLP160t1 = Curve(
    "BRAINPOOLP160t1",
    curve_brainpoolp160t1,
    generator_brainpoolp160t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 2),
    "brainpoolP160t1",
)

BRAINPOOLP192r1 = Curve(
    "BRAINPOOLP192r1",
    curve_brainpoolp192r1,
    generator_brainpoolp192r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 3),
    "brainpoolP192r1",
)

BRAINPOOLP192t1 = Curve(
    "BRAINPOOLP192t1",
    curve_brainpoolp192t1,
    generator_brainpoolp192t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 4),
    "brainpoolP192t1",
)

BRAINPOOLP224r1 = Curve(
    "BRAINPOOLP224r1",
    curve_brainpoolp224r1,
    generator_brainpoolp224r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 5),
    "brainpoolP224r1",
)

BRAINPOOLP224t1 = Curve(
    "BRAINPOOLP224t1",
    curve_brainpoolp224t1,
    generator_brainpoolp224t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 6),
    "brainpoolP224t1",
)

BRAINPOOLP256r1 = Curve(
    "BRAINPOOLP256r1",
    curve_brainpoolp256r1,
    generator_brainpoolp256r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 7),
    "brainpoolP256r1",
)

BRAINPOOLP256t1 = Curve(
    "BRAINPOOLP256t1",
    curve_brainpoolp256t1,
    generator_brainpoolp256t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 8),
    "brainpoolP256t1",
)

BRAINPOOLP320r1 = Curve(
    "BRAINPOOLP320r1",
    curve_brainpoolp320r1,
    generator_brainpoolp320r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 9),
    "brainpoolP320r1",
)

BRAINPOOLP320t1 = Curve(
    "BRAINPOOLP320t1",
    curve_brainpoolp320t1,
    generator_brainpoolp320t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 10),
    "brainpoolP320t1",
)

BRAINPOOLP384r1 = Curve(
    "BRAINPOOLP384r1",
    curve_brainpoolp384r1,
    generator_brainpoolp384r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 11),
    "brainpoolP384r1",
)

BRAINPOOLP384t1 = Curve(
    "BRAINPOOLP384t1",
    curve_brainpoolp384t1,
    generator_brainpoolp384t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 12),
    "brainpoolP384t1",
)

BRAINPOOLP512r1 = Curve(
    "BRAINPOOLP512r1",
    curve_brainpoolp512r1,
    generator_brainpoolp512r1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 13),
    "brainpoolP512r1",
)

BRAINPOOLP512t1 = Curve(
    "BRAINPOOLP512t1",
    curve_brainpoolp512t1,
    generator_brainpoolp512t1,
    (1, 3, 36, 3, 3, 2, 8, 1, 1, 14),
    "brainpoolP512t1",
)

Ed25519 = Curve(
    "Ed25519",
    curve_ed25519,
    generator_ed25519,
    (1, 3, 101, 112),
)

Ed448 = Curve(
    "Ed448",
    curve_ed448,
    generator_ed448,
    (1, 3, 101, 113),
)

# no order in particular, but keep previously added curves first
curves = [
    NIST192p,
    NIST224p,
    NIST256p,
    NIST384p,
    NIST521p,
    SECP256k1,
    BRAINPOOLP160r1,
    BRAINPOOLP192r1,
    BRAINPOOLP224r1,
    BRAINPOOLP256r1,
    BRAINPOOLP320r1,
    BRAINPOOLP384r1,
    BRAINPOOLP512r1,
    SECP112r1,
    SECP112r2,
    SECP128r1,
    SECP160r1,
    Ed25519,
    Ed448,
    BRAINPOOLP160t1,
    BRAINPOOLP192t1,
    BRAINPOOLP224t1,
    BRAINPOOLP256t1,
    BRAINPOOLP320t1,
    BRAINPOOLP384t1,
    BRAINPOOLP512t1,
]


def find_curve(oid_curve):
    """Select a curve based on its OID

    :param tuple[int,...] oid_curve: ASN.1 Object Identifier of the
        curve to return, like ``(1, 2, 840, 10045, 3, 1, 7)`` for ``NIST256p``.

    :raises UnknownCurveError: When the oid doesn't match any of the supported
        curves

    :rtype: ~ecdsa.curves.Curve
    """
    for c in curves:
        if c.oid == oid_curve:
            return c
    raise UnknownCurveError(
        "I don't know about the curve with oid %s."
        "I only know about these: %s" % (oid_curve, [c.name for c in curves])
    )


def curve_by_name(name):
    """Select a curve based on its name.

    Returns a :py:class:`~ecdsa.curves.Curve` object with a ``name`` name.
    Note that ``name`` is case-sensitve.

    :param str name: Name of the curve to return, like ``NIST256p`` or
        ``prime256v1``

    :raises UnknownCurveError: When the name doesn't match any of the supported
        curves

    :rtype: ~ecdsa.curves.Curve
    """
    for c in curves:
        if name == c.name or (c.openssl_name and name == c.openssl_name):
            return c
    raise UnknownCurveError(
        "Curve with name {0!r} unknown, only curves supported: {1}".format(
            name, [c.name for c in curves]
        )
    )

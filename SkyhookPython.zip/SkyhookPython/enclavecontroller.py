from GCM import GCM_encrypt, GCM_decrypt, convertType
from counter import Counter

class EnclaveController:
    keysize = "SIZE_256"
    tagsize = 16

    key: bytes
    counter: Counter

    def __init__(self, storage):
        self.counter = Counter()
#        self.test_encryption()
        print("Crypto Initialized")

    def encrypt(self, plaintext):
        emptyString = bytes()  # zero length bit string
        plaintext = convertType(plaintext)
        (ciphertext, tag) = GCM_encrypt(self.keysize, self.key, self.counter.to_bytes(), plaintext, emptyString)

        return ciphertext + tag

    def decrypt(self, encrypted_message):
        empty_string = bytes()  # zero length bit string
        encrypted_message = convertType(encrypted_message)
        ciphertext_length = len(encrypted_message) - self.tagsize
        ciphertext = encrypted_message[:ciphertext_length]
        tag = encrypted_message[ciphertext_length:]
        (success, plaintext) = GCM_decrypt(self.keysize, self.key, self.counter.to_bytes(), ciphertext, empty_string, tag)

        return success, plaintext

#     TODO: write tests
    def test_encryption(self):
        print("\nTesting encryption")
        test_string = "Hello Crypto"
        ciphertext = self.encrypt(test_string)
        plaintext = self.decrypt(ciphertext)

        if (test_string == plaintext):
            print("The encryption test succeeded.\n")
        else:
            print("The encryption test failed.\n")


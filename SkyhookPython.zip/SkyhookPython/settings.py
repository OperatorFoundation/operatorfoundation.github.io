# GPIO22 #SPI CLOCK, SD CARD
import board
from digitalio import DigitalInOut, Direction, Pull

class Settings:
    errorResponse = "SH+ERROR:"
    okResponse = "SH+OK\r\n"
    okWithMessageResponse = "SH+OK:"
    connectedResponse = "SH+CONNECTED\r\n"

    def __init__(self):
        self.DEBUG = False

        self.SCK = board.SCK

        # GPIO23 #SPI DATA TO DEVICES, CONTROLLER OUT PERIPHERAL IN, SD CARD
        self.COPI = board.COPI

        # GPIO20 #SPI DATA FROM DEVs, CONTROLLER IN PERIPHERAL OUT, SD CARD
        self.CIPO = board.CIPO

        # GPIO21 #CHIP SELECT FOR SD CARD
        self.SD_CS = board.CS

        # GPIO9 SD CARD DETECT, HIGH = NO CARD, LOW = CARD
        self.SD_CARD_DET = DigitalInOut(board.SDIO_DATA3)
        self.SD_CARD_DET.direction = Direction.INPUT
        self.SD_CARD_DET.pull = Pull.UP

        # GPIO1  #UART SERIAL RECEIVE, TALK WITH MODEM
        self.UART_RX = board.RX

        # GPIO0  #UART SERIAL TRANSMIT, TALK WITH MODEM
        self.UART_TX = board.TX

        # GPIO3  #STATUS OF MODEM'S POWER SUPPLY, HIGH=POWERED UP
        self.SPLY_OUT = DigitalInOut(board.PWM0)
        self.SPLY_OUT.direction = Direction.INPUT


        # GPIO24 #ENABLE/DISABLE POWER SUPPLIES FOR MODEM, HIGH = ENABLED
        self.RADIO_EN = DigitalInOut(board.PWM1)
        self.RADIO_EN.direction = Direction.OUTPUT
        self.RADIO_EN.value = False

        # GPIO2  #IRIDUM, CONTROL IRIDIUM MODEM ON/OFF STATE, HIGH=ON
        self.ON_OFF = DigitalInOut(board.A0)
        self.ON_OFF.direction = Direction.OUTPUT
        self.ON_OFF.value = False

        # GPIO5  #I2C CLOCK, ONLY FOR QWIIC/STEMMA CONNECTOR
        self.SCL = board.SCL

        # GPIO4  #I2C DATA, ONLY FOR QWIIC/STEMMA CONNECTOR
        self.SDA = board.SDA

        # GPIO6  #RGB NEOPIXEL, WS2812B
        self.NEOPIXEL = board.D0

        # The MicroMod processor's onboard LED, located on a corner of MicroMod proc PCB
        # Handy for debugging
        self.LED = DigitalInOut(board.LED)
        self.LED.direction = Direction.OUTPUT
        # LED.value = False # True
import binascii
import gc

from main import encryptionController, modemController, settings
gc.collect()


def send(message: bytes):
    ciphertext = encryptionController.sdEncrypt(message)
    modemController.send_data(ciphertext)

def receive():
    data = modemController.receive_data()

    if data != None:
        if settings.DEBUG:
            print(">>> Received a message <<<")
            print("Byte count:")
            print(len(data)/2)
            print("Message HEX:")
            print(data)
            print(">>> End of message <<<")

        (success, plaintext) = encryptionController.sdDecrypt(binascii.unhexlify(data))

        if success:
            print(settings.okWithMessageResponse + plaintext.decode() + "\r\n")
            print("*RECEIVED MESSAGE START*" + plaintext.decode() + "*RECEIVED MESSAGE END*")
        else:
            print("Message decryption failed.")
            print(settings.errorResponse + "DECRYPT FAILURE\r\n")

# def sendUnencrypted(message: bytes) -> bool:
#     modemController.send_data(message)
#     return True

# def receiveUnencrypted() -> str:
#     message = modemController.receive_text()
#     if settings.DEBUG:
#         print(">>> Received a message <<<")
#         print(message)
#         print(">>> End of message <<<")
#     return message
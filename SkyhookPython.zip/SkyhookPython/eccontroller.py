import gc
from circuitpython_base64 import b64decode, b64encode
gc.collect()
from ecdsa import ECDH, NIST256p, SigningKey, VerifyingKey
gc.collect()

class ECController:

    def __init__(self, storage):
        self.storage = storage
        self.sdGetOrGeneratePrivateKey()
        self.sdGenerateAndSaveSharedSecret()
        self.sdPrintUserPublicKey()
        gc.collect()

    def sdGenerateAndSavePrivateKey(self) -> SigningKey:
        newPrivateKey = SigningKey.generate(curve=NIST256p)

        if self.storage.settings.DEBUG:
            print("Generated a new private key")

        self.storage.writePrivateKey(newPrivateKey.to_string())
        self.sdPrintUserPublicKey()
        return newPrivateKey

    def sdGenerateAndSaveSharedSecret(self):
        contactPublicKeyBytes: bytes = self.storage.readPublicKey()

        # print("sdGenerateSharedSecret got a public key: ", contactPublicKeyBytes)
        # print("public key hex: ", binascii.hexlify(contactPublicKeyBytes))
        # print("public key size: ", len(contactPublicKeyBytes))

        userPrivateKey: SigningKey = self.sdGetOrGeneratePrivateKey()
        # print("sdGenerateSharedSecret got a private key: ", userPrivateKey)

        # newPublicKey = userPrivateKey.get_verifying_key()
        # print("created a public key from a private key: ", newPublicKey)
        # print("new public key size: ", len(newPublicKey.to_string(encoding="uncompressed")))

        ecdh = ECDH(curve=NIST256p)
        ecdh.load_private_key(userPrivateKey)

        # Do not include the first byte of the public key, that is a custom byte (Keychain format)
        cleanedPublicKeyBytes = contactPublicKeyBytes[1:]
        contactPublicKey: VerifyingKey = VerifyingKey.from_string(cleanedPublicKeyBytes, curve=NIST256p,
                                                                  valid_encodings=["uncompressed"])
        ecdh.load_received_public_key(contactPublicKey)
        sdSharedSecretBytes = ecdh.generate_sharedsecret_bytes()
        self.sdSharedSecret: int = int.from_bytes(sdSharedSecretBytes, "big")  # AES wants this as an int not bytes
        self.storage.writeSharedSecret(sdSharedSecretBytes)
        print("\nWrote the shared secret to memory!")

    def sdPrintUserPublicKey(self):
        userPrivateKey = self.sdGetOrGeneratePrivateKey()
        userPublicKeyUncompressed = userPrivateKey.get_verifying_key().to_string(encoding="uncompressed")
        userPublicKeyKeychainFormat = b'\x02' + userPublicKeyUncompressed
        userPublicKeyBase64 = b64encode(userPublicKeyKeychainFormat)
        print("User's SD public key (contact needs this): ", userPublicKeyBase64)

    def sdGetOrGeneratePrivateKey(self) -> SigningKey:
        try:
            savedPrivateKeyBytes = self.storage.readPrivateKey()

            if savedPrivateKeyBytes == b'':
                return self.sdGenerateAndSavePrivateKey()
            else:
                savedPrivateKey = SigningKey.from_string(savedPrivateKeyBytes, curve=NIST256p)
                return savedPrivateKey

        except OSError as e:
            print("Failed to retrieve a private key, error: ", e)
            print("Generating a new private key.")
            return self.sdGenerateAndSavePrivateKey()

    @staticmethod
    def sdSetupContact(contactPublicKeyString: str, storage):
        newPublicKeyBytes = b64decode(contactPublicKeyString)
        storage.writePublicKey(newPublicKeyBytes)

def testPublicKeyEncoding():
    print("\nTesting encode and decode public key...")
    newPrivateKey = SigningKey.generate(curve=NIST256p)
    newPublicKey = newPrivateKey.get_verifying_key()
    newPublicKeyBytes = newPublicKey.to_string(encoding="uncompressed")
    print("testPublicKeyEncoding - created a public key from a private key: ", newPublicKeyBytes)
    print("testPublicKeyEncoding - new public key size: ", len(newPublicKeyBytes))

    try:
        contactPublicKey: VerifyingKey = VerifyingKey.from_string(newPublicKeyBytes, curve=NIST256p, valid_encodings=["uncompressed"])
        print("Success: public key generated from key bytes: ", contactPublicKey)
        print("\n")
    except RuntimeError as e:
        print("Failed to decode a public key, error: ", e)
        print("\n")

def testStoreKeyAndRetrieve(storage):
    print("\nTesting save and retrieve private key...")
    newPrivateKey = SigningKey.generate(curve=NIST256p)
    newPrivateKeyBytes = newPrivateKey.to_string()
    print("sdGenerateAndSavePrivateKey new private key bytes: ", newPrivateKeyBytes)
    print("private key size: ", len(newPrivateKeyBytes))
    storage.writePrivateKey(newPrivateKeyBytes)
    try:
        savedPrivateKeyBytes: bytes = storage.readPrivateKey()

        if savedPrivateKeyBytes == b'':
            print("Failed to find saved private key bytes")
        else:
            print("Retrieved saved private key bytes: ", savedPrivateKeyBytes)
            print("private key size: ", len(savedPrivateKeyBytes))

            savedPrivateKey = SigningKey.from_string(savedPrivateKeyBytes, curve=NIST256p)
            print("Success: private key generated from key bytes.")

        print("\n")
    except OSError as e:
        print("Failed to retrieve a private key, error: ", e)
        print("\n")
import gc

from board import board_id

from storagecontroller import StorageController
from settings import Settings
from encryptioncontroller import EncryptionController
from modemcontroller import ModemController

gc.collect()

settings = Settings()
storageController = StorageController(settings)
encryptionController = EncryptionController(storageController)
modemController = ModemController(settings)
gc.collect()

if settings.DEBUG:
    print("Starting...")
    print("Processor is: " + board_id)

if board_id != "sparkfun_micromod_rp2040":
    print("ERROR ERROR ERROR - board not supported, use only sparkfun_micromod_rp2040\n")

if settings.DEBUG:
    print("Setup Complete\n")

# PROVISIONING ONLY - Use a real public key from an access terminal
# --------------------------------------------------
# gc.collect()
# from eccontroller import ECController
# gc.collect()
# contactPublicKeyString = ""
# ECController.sdSetupContact(contactPublicKeyString, storageController)
# ECController(storageController)
# print("Encryption provisioning complete.\n")
# --------------------------------------------------
# PROVISIONING ONLY - Use a real public key from an access terminal

import binascii

from board import UART
from time import monotonic, sleep
from custom_adafruit_rockblock import RockBlock
from statuscodes import print_sbdix_status


class ModemController:
    maxRetries = 4

    def __init__(self, settings):
        self.settings = settings

        # enable modem power supply
        self.settings.RADIO_EN.value = True

        # turn on this PIN, so we can check SPLY_OUT.
        self.settings.ON_OFF.value = True

        if settings.DEBUG:
            print("Modem setup:")
            print(" wait for caps to charge")
            print(" " + str(monotonic()))

        while not self.settings.SPLY_OUT.value:
            sleep(1)
        sleep(2)

        if settings.DEBUG:
            print(" caps charged")
            print(" modem power status (High=ON): " + str(self.settings.SPLY_OUT.value))

        uart = UART()
        uart.baudrate = 19200

        tryagain = True
        while tryagain:
            try:
                self.rockblock_modem = RockBlock(uart)
                tryagain = False
            except Exception as e:
                sleep(1)

        if settings.DEBUG:
            print(" Modem Model: " + self.rockblock_modem.model)
            print("Modem Setup Complete\n")

        print(self.settings.connectedResponse)

    def satelliteSendMessage(self):
        print("Sending a message...")
        # Status (32, 35, 2, 0, 0, 0)
        # MO status = (32) status of outgoing transmission
        # MOMSN = (35) outbound sequence number
        # MT status = (2) status of inbound transmission
        # MTMSN = (0) inbound sequence number
        # MT length = (0) bytes received
        # MT queued = (0) messages waiting to be delivered
        status = self.rockblock_modem.satellite_transfer()
        moStatus = status[0]
        mtStatus = status[2]

        print_sbdix_status(status)

        # loop as needed
        retry = 1

        # MO Values:
        # 0 - 4 = Transmit successful
        # 32 = No network service
        while moStatus > 4:
            sleep(3)
            status = self.rockblock_modem.satellite_transfer()
            moStatus = status[0]
            mtStatus = status[2]

            print("retry send attempt: " + str(retry) + ":")
            print_sbdix_status(status)

            retry += 1
            if retry > self.maxRetries:
                break

        if moStatus > 4:
            print(self.settings.errorResponse + "SATTELITE CONNECT FAILURE\r\n")
            return

        if mtStatus == 1:
            print("Incoming message received while sending a message.")
            print("Message size (bytes): ", status[4])
            print(str(status[5]) + " additional messages waiting to be received.")

        print(self.settings.okResponse)

    def satelliteGetMessages(self):
        # Status (32, 35, 2, 0, 0, 0)
        # MO status [0] = (32) status of outgoing transmission
        # MOMSN [1] = (35) outbound sequence number
        # MT status [2] = (2) status of inbound transmission
        # MTMSN [3] = (0) inbound sequence number
        # MT length [4] = (0) bytes received
        # MT queued [5] = (0) messages waiting to be delivered
        status = self.rockblock_modem.satellite_transfer()
        mtStatus = status[2]
        print_sbdix_status(status)

        # loop as needed
        retry = 1

        # MO Values:
        # 32 = No network service
        while mtStatus > 1:
            sleep(0.5) # in seconds
            status = self.rockblock_modem.satellite_transfer()
            mtStatus = status[2]

            print("retry attempt: " + str(retry) + ":")

            print_sbdix_status(status)

            retry += 1
            if retry > self.maxRetries:
                print(self.settings.errorResponse + "CONNECT FAILURE\r\n")
                return status

        return status


    def send_text(self, message: str):
        # set the text
        self.rockblock_modem.text_out = message

        # try a satellite Short Burst Data transfer
        self.satelliteSendMessage()

    def send_data(self, message_data: bytes):
        # put data in outbound buffer
        self.rockblock_modem.data_out = message_data

        # try a satellite Short Burst Data transfer
        self.satelliteSendMessage()

    def receive_text(self) -> str:
        # try a satellite Short Burst Data transfer
        self.satelliteGetMessages()
        print("\nDONE.")

        # return the text
        received_text = self.rockblock_modem.text_in
        if received_text is None:
            print("receive_text returned nothing")
            received_text = ""

        return received_text

    def receive_data(self) -> bytes:
        # try a satellite Short Burst Data transfer
        status = self.satelliteGetMessages()

        # get the raw data
        data = self.rockblock_modem.data_in

        if data is not None:
            if self.settings.DEBUG:
                print("receive_data(): Raw data = ", data)
            return data
        else:
            moStatus = status[0]

            if moStatus is 32:
                print(self.settings.errorResponse + "CONNECT FAILURE\r\n")
            else:
                mtStatus = status[2]
                if mtStatus is 0:
                    print(self.settings.okResponse)
                else:
                    print(self.settings.errorResponse + "INBOX ERROR\r\n")


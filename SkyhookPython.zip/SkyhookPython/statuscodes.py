def print_sbdix_status(status):
    # Status (32, 35, 2, 0, 0, 0)
    # MO status = (32) status of outgoing transmission
    # MOMSN = (35) outbound sequence number
    # MT status = (2) status of inbound transmission
    # MTMSN = (0) inbound sequence number
    # MT length = (0) bytes received
    # MT queued = (0) messages waiting to be delivered

    print("Status: ", status)
    mo_status = status[0]
    momsn = status[1]
    mt_status = status[2]
    mtmsn = status[3]
    mt_length = status[4]
    mt_queued = status[5]

    if mo_status == 0:
        print("MO message transferred successfully.")
    elif mo_status == 1:
        print("MO message transferred successfully, but the MT message in the queue was too big.")
    elif mo_status == 2:
        print("MO message transferred successfully, but the requested Location Update was not accepted.")
    elif mo_status == range(3, 4):
        print("Reserved value: MO session was successful.")
    elif mo_status == range(5, 8):
        print("Reserved value: MO session failed.")
    elif mo_status == 10:
        print("GSS reported that the call did not complete in the allowed time.")
    elif mo_status == 11:
        print("MO message queue at the GSS is full.")
    elif mo_status == 12:
        print("MO message has too many segments.")
    elif mo_status == 13:
        print("GSS reported that the session did not complete.")
    elif mo_status == 14:
        print("Invalid segment size.")
    elif mo_status == 15:
        print("Access is denied.")
    elif mo_status == 16:
        print("ISU has been locked and may not make SBD calls.")
    elif mo_status == 17:
        print("Gateway not responding (local session timeout).")
    elif mo_status == 18:
        print("Connection lost (RF drop).")
    elif mo_status == 19:
        print("Link failure (A protocol error caused termination of the call).")
    elif mo_status == range(20, 31):
        print("Reserved value: Failure.")
    elif mo_status == 32:
        print("No network service, unable to initiate call.")
    elif mo_status == 33:
        print("Antenna fault, unable to initiate call.")
    elif mo_status == 34:
        print("Radio is disabled, unable to initiate call.")
    elif mo_status == 35:
        print("ISU is busy, unable to initiate call.")
    elif mo_status == 36:
        print("Try later, must wait 3 minutes since last registration.")
    elif mo_status == 37:
        print("SBD service is temporarily disabled.")
    elif mo_status == 38:
        print("Try later, traffic management period.")
    elif mo_status == range(39, 63):
        print("Reserved value: Failure.")
    elif mo_status == 64:
        print("Band violation (attempt to transmit outside permitted frequency band).")
    elif mo_status == 65:
        print("PLL lock failure; hardware error during attempted transmit")
    else:
        print("Unknown MO_STATUS code: " + str(mo_status))

    if mo_status < 4:
        print("Mobile Originated Message Sequence Number: " + str(momsn))

        if mt_status == 0:
            print("No SBD message to receive from the GSS.")
        elif mt_status == 1:
            print("SBD message successfully received from the GSS.")
            print("Mobile Terminated Message Sequence Number: " + str(mtmsn))
            print(str(mt_length) + " bytes of the mobile terminated SBD message received from the GSS.")
            print(str(mt_queued) + " mobile terminated SBD messages waiting at the GSS to be transferred to the ISU.")
        elif mt_status == 2:
            print("An error occurred while attempting to perform a mailbox check or receive a message from the GSS.")
        else:
            print("Unknown MT status code: " + str(mt_status))

def print_sbdsx_response(status):
    print("\nSBDSX response:")
    mo_flag = status[0]
    momsn = status[1]
    mt_flag = status[2]
    mtmsn = status[3]
    ra_flag = status[4]
    msg_waiting = status[5]

    if mo_flag == 0:
        print("No message in mobile originated buffer.")
    elif mo_flag == 1:
        print("Message in mobile originated buffer.")
    else:
        print("Unknown MO flag status code: " + str(mo_flag))

    print("Mobile Originated Message Sequence Number: " + str(momsn))

    if mt_flag == 0:
        print("No message in mobile terminated buffer.")
    elif mt_flag == 1:
        print("Message in mobile terminated buffer.")
    else:
        print("Unknown MT flag status code: " + str(mt_flag))

    if mtmsn == -1:
        print("Nothing in the mobile terminated buffer")
    else:
        print("Mobile Terminated Message Sequence Number: " + str(mtmsn))

    if ra_flag == 0:
        print("No SBD ring alert.")
    elif ra_flag == 1:
        print("SBD ring alert has been received and needs to be answered.")
    else:
        print("Unknown RA flag status code: " + str(ra_flag))

    print(str(msg_waiting) + " SBD mobile terminated messages queued at the gateway.")
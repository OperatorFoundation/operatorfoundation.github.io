import binascii
from os import urandom
from binascii import hexlify
from GCM import GCM_encrypt, GCM_decrypt, convertType


class EncryptionController:
    keysize = "SIZE_256"
    tagsize = 16
    ivsize = 12 # in bytes

    def __init__(self, storage):
        self.storage = storage
        sharedSecretBytes = storage.readSharedSecret()

        if self.storage.settings.DEBUG:
            print("Shared Secret Bytes: ", str(binascii.hexlify(sharedSecretBytes)))

        self.sdSharedSecret = int.from_bytes(sharedSecretBytes, "big")

    def sdEncrypt(self, plaintext):
        iv = urandom(self.ivsize)
        emptyString = bytes()  # zero length bit string
        plaintext = convertType(plaintext)
        (ciphertext, tag) = GCM_encrypt(self.keysize, self.sdSharedSecret, iv, plaintext, emptyString)

        if self.storage.settings.DEBUG:
            print("-> ciphertext: ", str(binascii.hexlify(ciphertext)))
            print("-> tag: ", str(binascii.hexlify(tag)))

        encrypted = iv + ciphertext + tag

        if self.storage.settings.DEBUG:
            print("-> encrypted payload: ", str(binascii.hexlify(encrypted)))
            print()

        return encrypted

    def sdDecrypt(self, encrypted_message) -> (bool, bytes):
        empty_string = bytes()  # zero length bit string
        encrypted_message = convertType(encrypted_message)
        ciphertext_length = len(encrypted_message) - (self.tagsize + self.ivsize)
        iv = encrypted_message[:self.ivsize]
        ciphertext = encrypted_message[self.ivsize:ciphertext_length + self.ivsize]
        tag = encrypted_message[self.ivsize + ciphertext_length:]

        if self.storage.settings.DEBUG:
            print()
            print("<- Calling GCM_decrypt:")
            print("<- Encrypted Payload: ", str(encrypted_message))
            print("<- Encrypted Message Size: ", len(encrypted_message))
            print("<- Cipher Text Length: ", ciphertext_length)
            print("<- iv size: ", self.ivsize)
            print("<- tag size: ", self.tagsize)
            print("<- iv: ", str(iv))
            print("<- ciphertext: ", str(ciphertext))
            print("<- emptystring: ", empty_string)
            print("<- tag: ", str(tag))
            print()

        (success, plaintext) = GCM_decrypt(self.keysize, self.sdSharedSecret, iv, ciphertext, empty_string, tag)

        return success, plaintext

    def enclaveEncrypt(self, plaintext):
        # FIXME: Use EnclaveGCM
        iv = urandom(self.ivsize)
        emptyString = bytes()  # zero length bit string
        plaintext = convertType(plaintext)
        (ciphertext, tag) = GCM_encrypt(self.keysize, self.sdSharedSecret, iv, plaintext, emptyString)

        return iv + ciphertext + tag

    def enclaveDecrypt(self, encrypted_message):
        # FIXME: Use EnclaveGCM
        empty_string = bytes()  # zero length bit string
        encrypted_message = convertType(encrypted_message)
        ciphertext_length = len(encrypted_message) - (self.tagsize + self.ivsize)
        iv = encrypted_message[:self.ivsize]
        ciphertext = encrypted_message[self.ivsize:ciphertext_length]
        tag = encrypted_message[self.ivsize + ciphertext_length:]
        (success, plaintext) = GCM_decrypt(self.keysize, self.sdSharedSecret, iv, ciphertext, empty_string, tag)

        return success, plaintext

    def testSDEncryption(self):
        print("\nTesting encryption")
        test_string = "Hello Crypto"
        print("Test string: ", test_string)

        ciphertext = self.sdEncrypt(test_string)
        print("Ciphertext: ", hexlify(ciphertext))

        decryptResult = self.sdDecrypt(ciphertext)

        if decryptResult[0]:
            print("The encryption test succeeded.\n")
        else:
            print("The encryption test failed.\n")

        print("decryptResult: ", decryptResult)

